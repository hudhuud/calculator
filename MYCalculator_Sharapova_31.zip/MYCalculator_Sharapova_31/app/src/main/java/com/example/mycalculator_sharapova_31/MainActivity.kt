import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import net.objecthunter.exp4j.ExpressionBuilder
import com.example.mycalculator_sharapova_31.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val result: TextView = findViewById(R.id.result) as TextView
        val operation: TextView = findViewById(R.id.operation) as TextView

        // Инициализация кнопок
        val b_sqrt: TextView = findViewById(R.id.b_sqrt)
        val b_log2: TextView = findViewById(R.id.b_log2)
        val b_ln: TextView = findViewById(R.id.b_ln)
        val b_leftb: TextView = findViewById(R.id.b_leftb)
        val b_rightb: TextView = findViewById(R.id.b_rightb)
        val b_pow: TextView = findViewById(R.id.b_pow)
        val b_sin: TextView = findViewById(R.id.b_sin)
        val b_cos: TextView = findViewById(R.id.b_cos)
        val b_PI: TextView = findViewById(R.id.b_PI)
        val b_e: TextView = findViewById(R.id.b_e)
        val b_0: TextView = findViewById(R.id.b_0)
        val b_1: TextView = findViewById(R.id.b_1)
        val b_2: TextView = findViewById(R.id.b_2)
        val b_3: TextView = findViewById(R.id.b_3)
        val b_4: TextView = findViewById(R.id.b_4)
        val b_5: TextView = findViewById(R.id.b_5)
        val b_6: TextView = findViewById(R.id.b_6)
        val b_7: TextView = findViewById(R.id.b_7)
        val b_8: TextView = findViewById(R.id.b_8)
        val b_9: TextView = findViewById(R.id.b_9)
        val b_mult: TextView = findViewById(R.id.b_mult)
        val b_div: TextView = findViewById(R.id.b_div)
        val b_plus: TextView = findViewById(R.id.b_plus)
        val b_minus: TextView = findViewById(R.id.b_minus)
        val b_dot: TextView = findViewById(R.id.b_dot)
        val b_back: TextView = findViewById(R.id.b_back)
        val b_clear: TextView = findViewById(R.id.b_clear)
        val b_equals: TextView = findViewById(R.id.b_equals)

        // Добавление символов к строке выражения при нажатии на кнопки

        // Кнопка удаления последнего символа
        b_back.setOnClickListener {
            val s = operation.text.toString()
            if (s.isNotEmpty()) {
                operation.text = s.substring(0, s.length - 1)
            }
        }

        // Кнопка очистки строки выражения и ответа
        b_clear.setOnClickListener {
            operation.text = ""
            result.text = ""
        }

        // Перенос ответа в поле выражения для продолжения вычислений
        result.setOnClickListener {
            val restext = result.text.toString()
            if (restext != "Error" && restext.isNotEmpty()) {
                operation.text = restext
                result.text = ""
            }
        }

        // Кнопка вычисления выражения
        b_equals.setOnClickListener {
            val optext = operation.text.toString()
            if (optext.isNotEmpty()) {
                try {
                    val expr = ExpressionBuilder(optext).build()
                    val res = expr.evaluate()
                    val longres = res.toLong()
                    result.text = if (longres.toDouble() == res) {
                        longres.toString()
                    } else {
                        res.toString()
                    }
                } catch (e: Exception) {
                    result.text = "Error"
                }
            }
        }
    }
}
